package main.java.animals;

public class Kotik {


    private static int count;
    private static final int METHODS = 5;
    private String name;
    private String voice;
    private int satiety;
    private int weight = 2;

    public Kotik(String name, String voice, int satiety, int weight) {
        this.name = name;
        this.voice = voice;
        this.satiety = satiety;
        this.weight = weight;
        Kotik.count += 1;
    }

    public Kotik() {
        Kotik.count += 1;
    }

    public static int getCount() {
        return count;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getVoice() {
        return voice;
    }

    public void setVoice(String voice) {
        this.voice = voice;
    }

    public int getSatiety() {
        return satiety;
    }

    public void setSatiety(int satiety) {
        this.satiety = satiety;
    }

    public int getWeight() {
        return weight;
    }

    public void setWeight(int weight) {
        this.weight = weight;
    }

    public void eat(int satiety) {
        this.satiety += satiety;
        System.out.println(this.name + " покушал ");
    }

    public void eat(int satiety, String brand) {
        this.satiety += satiety;
        System.out.println(this.name + " покушал " + brand);

    }

    public void eat() {

        this.eat(3, "kitkat");
    }


    public boolean play() {
        if (getSatiety() >= 0) {
            this.satiety -= 1;
            //System.out.println(name + "Гуляет");
            return true;
        } else {
            this.eat();
            return false;
        }

    }

    public boolean sleep() {
        if (getSatiety() >= 0) {
            this.satiety -= 1;
            //System.out.println(name + " Спит");
            return true;
        } else {
            this.eat();
            return false;
        }

    }

    public boolean wash() {
        if (getSatiety() >= 0) {
            this.satiety -= 1;
            //System.out.println(name + " Моется");
            return true;
        } else {
            this.eat();

            return false;
        }

    }

    public boolean walk() {
        if (getSatiety() >= 0) {
            this.satiety -= 1;
            //System.out.println(name + " Гуляет");
            return true;
        } else {
            this.eat();
            return false;
        }

    }

    public boolean hunt() {
        if (getSatiety() >= 0) {
            int satiety = -1;
            //System.out.println(name + " Охотится");
            return true;
        } else {
            this.eat();
            return false;
        }

    }


    public String[] liveAnotherDay() {
        String[] activityRecords = new String[24];

        for (int i = 0; i < 24; i++) {
            activityRecords[i] = "Время " + String.valueOf(i) + " - ";
            switch ((int) (Math.random() * METHODS) + 1) {
                case 1:
                    this.play();
                    activityRecords[i] += "Играл";
                    break;
                case 2:
                    this.hunt();
                    activityRecords[i] += "Охотился";
                    break;
                case 3:
                    this.walk();
                    activityRecords[i] += "Гулял";
                    break;
                case 4:
                    this.wash();
                    activityRecords[i] += "Мылся";
                    break;
                case 5:
                    this.sleep();
                    activityRecords[i] += "Спал";
                    break;
            }
        }
        return activityRecords;
    }
    public static boolean compareVoice(Kotik k1, Kotik k2){
        if(k1.getVoice().equals(k2.getVoice())){
            return true;
        }
        return false;

    }



}
